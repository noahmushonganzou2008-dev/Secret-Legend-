SECRET LEGEND — FULL WEBSITE

Files:
- index.html
- assets/artist.jpg

To preview:
1. Extract the ZIP.
2. Open index.html in a web browser.

The site includes:
Home, About, Music, Gallery, Social, and Contact sections.
The YouTube button uses the handle supplied for Secret Legend.
Facebook buttons are placeholders until the exact page URLs are supplied.

For publishing, upload the whole folder while keeping assets/artist.jpg beside index.html.
